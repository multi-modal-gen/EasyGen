# EasyGen
The official code for paper "Making Multimodal Generation Easier: When Diffusion Models Meet LLMs"
